const EnrolledClass = () => {
  return (
    <div>
      <h2>EnrollClass</h2>
    </div>
  );
};

export default EnrolledClass;
