const SelectedClass = () => {
  return (
    <div>
      <h2>SelectedClass</h2>
    </div>
  );
};

export default SelectedClass;
